package week04.HW;

public class AddOperation extends AbstractOperation {
    @Override
    double operate(int a, int b){
        return a+b;
    }
}
