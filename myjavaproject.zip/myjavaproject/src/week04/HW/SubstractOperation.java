package week04.HW;

public class SubstractOperation extends AbstractOperation {
    @Override
    double operate(int a, int b){
        return a-b;
    }
}
