package week03.HW;

public abstract class AbstractOperation {
    abstract double operate(int a, int b);
}
