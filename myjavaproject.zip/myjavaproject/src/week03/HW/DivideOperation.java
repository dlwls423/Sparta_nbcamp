package week03.HW;

public class DivideOperation extends AbstractOperation {
    @Override
    double operate(int a, int b){
        return (double)a/b;
    }
}
