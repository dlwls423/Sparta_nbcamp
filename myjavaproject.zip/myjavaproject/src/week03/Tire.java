package week03;

public class Tire {
    public Tire() {
        System.out.println("타이어가 생성되었습니다.");
    }
}
