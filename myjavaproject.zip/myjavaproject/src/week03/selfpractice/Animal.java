package week03.selfpractice;

public class Animal {
    void sound() {
        System.out.println();
    }
}
