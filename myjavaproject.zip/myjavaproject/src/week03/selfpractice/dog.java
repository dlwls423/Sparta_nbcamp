package week03.selfpractice;

public class dog extends Animal{
    @Override
    void sound(){
        System.out.println("강아지 멍멍");
    }
}
