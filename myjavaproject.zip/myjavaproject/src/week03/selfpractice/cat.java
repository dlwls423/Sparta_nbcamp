package week03.selfpractice;

public class cat extends Animal{
    @Override
    void sound(){
        System.out.println("고양이 냐옹");
    }
}
