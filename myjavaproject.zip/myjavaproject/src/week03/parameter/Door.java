package week03.parameter;

public class Door {
    public Door() {
        System.out.println("문 객체가 생성되었습니다.");
    }
}
