package week03.parameter;

public class Tire {
    String company; // 타이어 회사
    public Tire() {}
}
