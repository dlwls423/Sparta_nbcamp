package week03.pakageExample.pk2;

public class Car {
    public void horn() {
        System.out.println("pk2 빵~!");
    }
}
