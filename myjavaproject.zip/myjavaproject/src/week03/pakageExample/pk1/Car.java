package week03.pakageExample.pk1;

public class Car {
    public void horn() {
        System.out.println("pk1 빵~!");
    }
}
