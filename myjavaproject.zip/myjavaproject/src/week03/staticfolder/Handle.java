package week03.staticfolder;

public class Handle {
    public Handle() {
        System.out.println("핸들 객체가 생성되었습니다.");
    }
}
