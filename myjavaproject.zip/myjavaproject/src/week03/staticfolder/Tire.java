package week03.staticfolder;

public class Tire {
    String company; // 타이어 회사
    public Tire() {}
}
