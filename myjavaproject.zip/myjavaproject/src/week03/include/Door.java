package week03.include;

public class Door {
    String company; // 차문 회사
    String location; // 차문 위치, FL, FR, BL, BR

    public Door(String company, String location) {
        this.company = company;
        this.location = location;
    }
}
